<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Task;
use App\User;

class TaskController extends Controller
{
    public function index($value='')
    {
    	$employees = User::where(['user_type'=>2])->get();
    	return view('add_task', compact('employees'));
    }

    public function save_task(Request $request)
    {
    	//dd($request); exit;

    	$validated = $request->validate([
            'task_name' => 'required|string',
            'discription' => 'required|string',
            'employee' =>'required',
        ]);

        $validated['reporting']  = Auth::User()->id;

        //dd($validated); exit;

        Task::create(['task_name'=>$validated['task_name'], 'discription'=>$validated['discription'],  'employee'=>$validated['employee'], 'reporting'=>$validated['reporting'], 'status'=>'assigned']);

        return redirect()->route('add_task');
    }
}
