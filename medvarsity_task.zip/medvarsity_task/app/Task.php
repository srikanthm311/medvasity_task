<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Task extends Model
{
    protected $table='tasks';
    protected $fillable=[
        'task_name', 'discription', 'employee', 'reporting', 'status'
    ];


    public function userDetails()
    {
        return $this->belongsTo(User::class, 'employee');
    }

    public function managerDetails()
    {
        return $this->belongsTo(User::class, 'reporting');
    }
}
