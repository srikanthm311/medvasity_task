@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Dashboard') }}</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    {{ __('You are logged in!') }}

                    <h1>tasks Assigned to you</h1>
                    <table class="table tbl_header">
                        <thead>
                            <tr>
                                <th>Task</th>
                                <th>Discription</th>
                                <th>assigned By</th>
                                <th>created At</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $i = 1; ?>
                            @foreach($tasks as $eachStaff)
                            <tr>
                                <td>
                                   {{$i}}
                                </td>
                                <td>
                                    {{$eachStaff->task_name}}
                                </td>
                                <td>
                                    {{$eachStaff->discription}}
                                </td>
                                <td>
                                    {{$eachStaff->managerDetails->name}}
                                </td>
                            </tr>

                                <?php
                                $i++;
                                ?>
                            @endforeach    
                        </tbody>
                        
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
